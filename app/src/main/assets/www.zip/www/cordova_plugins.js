cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "cordova-plugin-device.device",
    "file": "plugins/cordova-plugin-device/www/device.js",
    "pluginId": "cordova-plugin-device",
    "clobbers": [
      "device"
    ]
  },
  {
    "id": "cordova-plugin-dialogs.notification",
    "file": "plugins/cordova-plugin-dialogs/www/notification.js",
    "pluginId": "cordova-plugin-dialogs",
    "merges": [
      "navigator.notification"
    ]
  },
  {
    "id": "cordova-plugin-dialogs.notification_android",
    "file": "plugins/cordova-plugin-dialogs/www/android/notification.js",
    "pluginId": "cordova-plugin-dialogs",
    "merges": [
      "navigator.notification"
    ]
  },
   {
     "id": "cordova-plugin-dapp.dapp",
     "file": "plugins/cordova-plugin-dapp/www/dapp.js",
     "pluginId": "cordova-plugin-dapp",
     "merges": [
       "navigator.dapp"
     ]
   },
   {
     "id": "cordova-plugin-cctime.cctime",
     "file": "plugins/cordova-plugin-cctime/www/cctime.js",
     "pluginId": "cordova-plugin-cctime",
     "merges": [
       "navigator.cctime"
     ]
   }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-plugin-device": "1.1.7",
  "cordova-plugin-dialogs": "1.3.4",
  "cordova-plugin-dapp": "1.0.0",
  "cordova-plugin-cctime": "1.0.0"
};
// BOTTOM OF METADATA
});